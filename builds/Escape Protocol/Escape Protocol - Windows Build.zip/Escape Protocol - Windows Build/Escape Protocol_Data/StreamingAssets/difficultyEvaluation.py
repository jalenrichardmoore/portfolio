def evaluate_entry():

    import UnityEngine
    import pickle
    import os

    import xgboost as xgb

    evaluationManager = UnityEngine.GameObject.FindWithTag("Evaluation Manager").GetComponent("EvaluationManager")
    sessionData = evaluationManager.sessionData

    model_path = os.path.join(UnityEngine.Application.dataPath, 'StreamingAssets/evaluationModel.pkl')
    with open(model_path, 'rb') as model_file:
        xgBoost = pickle.load(model_file)

    features = list(sessionData.keys())
    entry = [[sessionData[feature] for feature in features]]

    prediction = xgBoost.predict(entry)[0]

    # xgBoost.fit(entry, prediction)
    with open(model_path, 'wb') as model_file:
        pickle.dump(xgBoost, model_file)

    if prediction == 0: evaluationManager.AdjustDifficulty("Decrease")
    elif prediction == 1: evaluationManager.AdjustDifficulty("Stay the same")
    elif prediction == 2: evaluationManager.AdjustDifficulty("Increase")